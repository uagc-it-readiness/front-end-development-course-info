import React, { Component } from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'; 
import BootstrapTable from 'react-bootstrap-table-next';

class DividendTable extends Component {
    state = {
        renderedData: [],
        columns: [{
          dataField: 'ticker',
          text: 'Ticker Symbol',
          sort: true
        },
        {
          dataField: 'amount',
          text: 'dividend'
        }]
      } 
      
      render() {
        this.state.renderedData.push(...this.props.data);  
        return (
          <div className="container" style={{ marginTop: 50 }}>
            <BootstrapTable 
            striped
            hover
            keyField='id' 
            data={this.state.renderedData}
            columns={ this.state.columns } />
          </div>
        );
      }
    }
export default DividendTable;
