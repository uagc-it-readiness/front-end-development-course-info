//example single stock: https://api.iextrading.com/1.0/stock/JNJ/dividends/1y
//their api for getting dividends for multiple stocks at once appears to be broken:  https://api.iextrading.com/1.0/stock/market/batch?symbols=JNJ,XOM&types=dividends&range=1m&last=5
const getObjectFromJson = response => response.json();

const throwIfNotOk = response => {
    if (!response.ok) {
      throw Error(response.statusText);
    }
    return response;
  };
  
  const sleep = (msecs) => (
    results => new Promise(resolve => setTimeout(() => resolve(results), msecs))
  );
  
  const getUrl = response => { 
    return response;
  }
  
  const loadDividends = (query) => {
    const encodedQuery = encodeURIComponent(query);
    const url = `https://api.iextrading.com/1.0/stock/${encodedQuery}/dividends/1y`;
    return fetch(url)
      .then(throwIfNotOk)
      .then(getObjectFromJson)
      .then(getUrl)
      .then(sleep(1000));
  };
  
  export default loadDividends;