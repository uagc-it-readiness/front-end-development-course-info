import React, { Component } from 'react';
import DividendData from '../DividendData';

export default class TickerInput extends Component {
    constructor(...args){
        super();
        this.onSubmit = this.onSubmit.bind(this);
        this.massageData = this.massageData.bind(this);
        this.ticker = '';
    }

    onSubmit(tickerInput){
        tickerInput.preventDefault();
        const query = tickerInput.target.elements.ticker.value;
        this.ticker = query;
        this.props.onSearch(query);
    }

    massageData(data){
        if(data){
            let annualDividend = data.length * data[0].amount;
            return [{ticker: this.ticker, amount: annualDividend}];   
        }else{
            return data;
        }
    }

    render(){
        return (
            <section>
                <form onSubmit={this.onSubmit}>
                    <div>
                        Enter a ticker symbol:
                        <input type="text" name="ticker"></input>
                        <button type="submit">Add to Chart</button>
                    </div>
                    <section>
                        <this.DisplayData data={this.massageData(this.props.data)}></this.DisplayData>
                    </section>
                    
                </form>
            </section>
        );
    }

    DisplayData(props){
        if(props.data){
            return (
            //     <ul>
            // {props.data.map(function(element, index, array){
            //     return <div>{element.exDate}</div>
            // })}
            // </ul>
            <DividendData data={props.data}></DividendData>
            )
        }else{
            return <div>No Data</div>
        }
    }
}