import React, { Component } from 'react';
import DividendData from '../DividendData';

export default class TickerInput extends Component {
    constructor(...args){
        super();
        this.onSubmit = this.onSubmit.bind(this);
    }

    onSubmit(tickerInput){
        //Some Ajax call to 3p stock API
        tickerInput.preventDefault();
        const query = tickerInput.target.elements.ticker.value;
        this.props.onSearch(query);
    }

    render(){
        return (
            <section>
                <form onSubmit={this.onSubmit}>
                    <div>
                        Enter a ticker symbol:
                        <input type="text" name="ticker"></input>
                        <button type="submit">Add to Chart</button>
                    </div>
                    <section>
                        <this.DisplayData data={this.props.data}></this.DisplayData>
                    </section>
                    
                </form>
            </section>
        );
    }

    DisplayData(props){
        debugger;
        if(props.data){
            return (
            //     <ul>
            // {props.data.map(function(element, index, array){
            //     return <div>{element.exDate}</div>
            // })}
            // </ul>
            <DividendData data={props.data}></DividendData>
            )
        }else{
            return <div>No Data</div>
        }
    }
}