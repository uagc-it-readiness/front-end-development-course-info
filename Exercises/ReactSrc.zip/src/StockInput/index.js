import React, {Component} from 'react';
import TickerInput from './TickerInput';
import loadData from './loadData';

export default class extends Component {
    state = {};
    load = this.load.bind(this);

    async load(...args){
        try {
            const data = await loadData(...args);
            this.setState({ data });
        }catch(ex){

        }
    }

    render() {
        return <TickerInput onSearch={this.load} {...this.state}></TickerInput>
    }   
}