import React, { Component } from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'; 
import BootstrapTable from 'react-bootstrap-table-next';

class DividendTable extends Component {
    state = {
        products: [
          {
            id: 'jnj',
            dividend: 0.84 
          }
        ],
        columns: [{
          dataField: 'type',
          text: 'Ticker Symbol',
          sort: true
        },
        {
          dataField: 'amount',
          text: 'dividend'
        }]
      } 
      
      render() {
          debugger;
        return (
          <div className="container" style={{ marginTop: 50 }}>
            <BootstrapTable 
            striped
            hover
            keyField='id' 
            data={ this.props.data } 
            columns={ this.state.columns } />
          </div>
        );
      }
    }
export default DividendTable;
